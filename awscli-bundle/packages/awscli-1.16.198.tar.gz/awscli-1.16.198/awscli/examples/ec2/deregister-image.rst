**To deregister an AMI**

This example deregisters the specified AMI. If the command succeeds, no output is returned.

Command::

  aws ec2 deregister-image --image-id ami-4fa54026
