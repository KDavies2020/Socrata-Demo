**To delete a policy**

The following example shows how to delete a policy from an organization. The example assumes that you previously detached the policy from all entities: ::

	aws organizations delete-policy --policy-id p-examplepolicyid111